/* C program to printf a sentence.*/
int r;
int h[2];
int printf();
float myfunc(int a, int b)
{
    return a*b;
} 
int main(/*int argc*/)
{
	
	double x = 0.1;
	float y = 1.5/3;
	int z = 3 + 2;
	r = x-3*4/2;
	y *= 2.5; 
	if(r > 3)
	{
    	printf("C PROGRAMMING %d\n//", 5);
	}
    {
    	int q;
    	{
    		float x;
    	}
    }
	switch(2)
	{
		case 0:
			printf("Z is equal 0\n");
			break;
		case 1:
			printf("z is equal 1\n");
			break;
		default:
			printf("Z is not 0 or 1\n");
			break;
	}
    z = myfunc(h[1],5);
    return 0;
}