/*#include <stdio.h>*/
void printf();
int main(int argc)
{
    printf("Hola Mundo");
}
