/* C program to printf a sentence.*/
int r;
int h[2];
int printf();
float myfunc(int a, int b)
{
    return a*b;
} 
int main(/*int argc*/)
{
	int i;
    int x = 6;
	int z = 3 + 2;
	r = x-3*4/2; 
	if(r > 3)
	{
    	printf("C PROGRAMMING %d\n//", 5);
	}
	else
	{
		r += 5;
	}

    for(i=0; i<5; i++)
    {
        printf("%d\n", i);
    }
    z = myfunc(h[1],5);
    return 0;
}