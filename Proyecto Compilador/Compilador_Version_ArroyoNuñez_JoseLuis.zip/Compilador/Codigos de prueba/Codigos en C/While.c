#include <stdio.h> 

#include <stdlib.h>
void puts();

int main() 
{
    int i=0; 

    while (i<3) {

        puts("hola\n");

        i=i+1;

    }

    return 0; 

}