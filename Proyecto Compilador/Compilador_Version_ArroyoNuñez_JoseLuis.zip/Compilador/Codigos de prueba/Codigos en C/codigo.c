/* C program to printf a sentence.*/
int r;
int g;
int h[2];
int printf();
float myfunc(int a, int b)
{
    return a*b;
} 
int main(/*int argc*/)
{
	
	double x = 0.1;
	float y = 1.5/3;
	int z = 3 + 2;
	g = z + 3;
	g = z++;
	g = --z; 
	g = sizeof(int);
	r = x-3*4/2;
	y *= 2.5; 
	if(r > 3)
	{
    	printf("C PROGRAMMING %d\n//", 5);
	}
	else
	{
		r += 5;
	}
    z = myfunc(h[1],5);
    return 0;
}