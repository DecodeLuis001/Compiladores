/*#include <stdio.h>*/

int i, nl, max, min, hl, ne, j, l;
int cap[28];
char ans= "S,s";

void printf();
void scanf();

int main()
{
  char op="a,b,c";
 intento:
  nl=0;
  printf("Numero de datos a capturar menor a 30 \n");
  scanf("%i",&nl);
  if(nl >=30)
    {
      printf("\n");
      printf("Numero de datos a capturar excede el limite \n");
      printf("Vuelve a intentar \n");
      goto intento;
    }
  
      for(l=0; l<nl; l++)
	{
	  printf("Dato %i \n", l+1);
	  scanf("%i",&cap[l]);
	}
      
 menu:
  printf("\n________________________________________________\n");
  printf("Que desea realizar con los datos ingresados: \n");
  printf("a) Buscar cual dato ingresado es el mayor \n");
  printf("b) Buscar cual dato ingresado es el menor \n");
  printf("c) Ordenar los Datos ingresados \n");
  scanf("%s",&op);

  switch(op)
    {
    case 'a':
    {
		printf("Buscar cual dato ingresado es el mayor \n");
		max=cap[0];
		for(i=0; i<nl; i++)
		{
			if(cap[i]>max)
			{
			max=cap[i];
			}
		}
		printf("El valor mayor ingresado es el %i",max);
		printf("\n________________________________________________\n");
		printf("¿Desea seleccionar otra opcion del menu?\n");
		printf("Si su respuesta es si ingrese S/s, de lo contrario ingrese cualquier otro caracter \n");
		scanf("%s",&ans);
		if(ans == 'S' || ans =='s')
		{
			goto menu;
		}
      break;
	}
      
    case 'b':
    {
		printf("Buscar cual dato ingresado es el menor \n");
		min=cap[0];
		for(i=0; i<nl; i++)
		{
			if(cap[i]<min)
			{
			min=cap[i];
			}
		}
		printf("El valor menor ingresado es el %i",min);
		printf("\n________________________________________________\n");
		printf("¿Desea seleccionar otra opcion del menu?\n");
		printf("Si su respuesta es si ingrese S/s, de lo contrario ingrese cualquier otro caracter \n");
		scanf("%s",&ans);
		if(ans == 'S' || ans =='s')
		{
			goto menu;
		}
      break;
	}

    case 'c':
    {
		printf("Ordenar los Datos ingresados \n");
	    for(j=0; j<nl; j++)
		{
	      for(i=j+1; i<nl; i++)
			if(cap[j] > cap[i])
			{
				hl=cap[j];
				cap[j] = cap[i];
				cap[i]=hl;
			}
		}

	    printf("Datos ordenados en orden ascendente \n");
	    printf("\n");
	    for(i=0; i<nl; i++)
	    {
			printf("\t %i\n",cap[i]);
	    }
	    
	    for(j=0; j<nl; j++)
		{
	      for(i=j+1; i<nl; i++)
			if(cap[j] < cap[i])
			{
				hl=cap[j];
				cap[j] = cap[i];
				cap[i]=hl;
			}
		}
	    printf("\n");
	    printf("Datos ordenados en orden ascendente \n");
	    for(i=0; i<nl; i++)
	    {
			printf("\t %i\n",cap[i]);
	    }
	    
	    printf("\n________________________________________________\n");
	    printf("¿Desea seleccionar otra opcion del menu?\n");
	    printf("Si su respuesta es si ingrese S/s, de lo contrario ingrese cualquier otro caracter \n");
	    scanf("%s",&ans);
	    if(ans == 'S' || ans =='s')
		{
			goto menu;
	    }
      break;
	}
    default:
      {
	printf("Opcion incorrecta intente de nuevo... \n");
	goto menu;
      }
    }
  
  return 0;
}
