void printf();
void scanf();

int main()
{
	char opcion="a,b,c";

	inicio:
	printf("--------------------------------- \n");
	printf("Elija una opcion: \n");
	printf("a)promedio con ciclo while \n");
	printf("b)promedio con ciclo do-while \n");
	printf("c)promedio con ciclo for \n");
	printf("\n");
	/*__fpurge(stdin);*/
	scanf("%c",&opcion);

	switch(opcion)
	{
		case 'a' :
		{
			int nd;
			int i=0;
			float dato, prom, contador=0;
			
			printf("Numero de datos a ingresar: \n");
			scanf("%i",&nd);
			while(i < nd)
			{
				i++;
				printf("Digite el dato numero %i: \n",i);
				scanf("%f",&dato);
				
				if(dato < 0)
				{
					break;
				}
				
				contador += dato;
			}
				
			if (nd == i)
			{
				prom=contador/nd;
				printf("Promedio %.3f \n",prom);
			}
			else
			{
				prom=contador/(i-1);
				printf("Promedio %.3f \n",prom);
			}
			break;
		}
	case 'b':
	{
		int nd, i=0, dato, j=0;
		float  prom, contador=0;
		
		printf("Numero de datos a ingresar: \n");
		scanf("%i",&nd);
		
		do
		{
			i++;
			j++;
			printf("Digite el dato numero %i: \n",i);
			scanf("%i",&dato);
			if(dato < 0)
			{
				break;
			}
			contador += dato;

			/*i++;
			//j++;*/
		}
		while(i < nd);
		
		if (nd == j && nd == 0)
		{
		prom=contador/nd;
		printf("Promedio %.3f \n",prom);
		}
		else
		{
		prom=contador/(j-1);
		printf("Promedio %.3f \n",prom);
		}
		break;
	}	
	case 'c':
	{
		int nd, i, j=0;
		float dato, prom, contador=0;
		
		printf("Numero de datos a ingresar: \n");
		scanf("%i",&nd);
		
		for(i=1; i<=nd; i++)
		{
		j++;
		printf("Digite en dato numero %i: \n",i);
		scanf("%f",&dato);
		contador += dato;
		
		if(dato < 0)
			{
			break;
			}
		}

		if (nd == j)
		{
		prom=contador/nd;
		printf("Promedio %.3f \n",prom);
		}
		else
		{
		prom=contador/(j-1);
		printf("Promedio %.3f \n",prom);
		}
		break;
	}

	default:
	{
		printf("No corresponde a una opcion \n");
		goto inicio;
		}
		break;
	}

	return 0;
}
