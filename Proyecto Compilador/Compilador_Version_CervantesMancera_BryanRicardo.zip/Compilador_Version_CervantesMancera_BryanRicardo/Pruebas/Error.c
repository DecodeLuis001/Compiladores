//Prueba 1 de compilador

void printf();
int vlr=1, i, ttl;
int main()
{
    
    ttl=vlr+4;

    for(i=0; i<ttl; i++)
    {
        printf("Valor numero: ",i);
    }

    return 0;
}